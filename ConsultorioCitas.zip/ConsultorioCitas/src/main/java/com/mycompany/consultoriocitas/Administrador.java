package com.mycompany.consultoriocitas;

public class Administrador {
    private final String usuario;
    private final String contraseña;

    public Administrador(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public boolean validar(String u, String c) {
        return usuario.equals(u) && contraseña.equals(c);
    }
}
