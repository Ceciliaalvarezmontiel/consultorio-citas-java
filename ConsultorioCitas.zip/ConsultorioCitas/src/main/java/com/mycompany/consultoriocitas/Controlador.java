package com.mycompany.consultoriocitas;

import java.util.List;
import java.util.Scanner;

public class Controlador {

    private final Administrador admin = new Administrador("admin", "1234");
    private final Scanner scanner = new Scanner(System.in);

    public void iniciar() {
        System.out.println("Bienvenido al sistema de citas médicas.");
        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contraseña = scanner.nextLine();

        if (!admin.validar(usuario, contraseña)) {
            System.out.println("Acceso denegado.");
            return;
        }

        int opcion;
        do {
            System.out.println("\n--- Menú ---");
            System.out.println("1. Dar de alta doctor");
            System.out.println("2. Dar de alta paciente");
            System.out.println("3. Crear cita");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> altaDoctor();
                case 2 -> altaPaciente();
                case 3 -> crearCita();
                case 4 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 4);
    }

    private void altaDoctor() {
        System.out.print("ID del doctor: ");
        String id = scanner.nextLine();
        System.out.print("Nombre del doctor: ");
        String nombre = scanner.nextLine();
        System.out.print("Especialidad: ");
        String especialidad = scanner.nextLine();

        Doctor doctor = new Doctor(id, nombre, especialidad);
        ArchivoManager.guardarDoctor(doctor);
        System.out.println("Doctor guardado en archivo.");
    }

    private void altaPaciente() {
        System.out.print("ID del paciente: ");
        String id = scanner.nextLine();
        System.out.print("Nombre del paciente: ");
        String nombre = scanner.nextLine();

        Paciente paciente = new Paciente(id, nombre);
        ArchivoManager.guardarPaciente(paciente);
        System.out.println("Paciente guardado en archivo.");
    }

    private void crearCita() {
        System.out.println("--- Crear Cita ---");

        List<Doctor> doctores = ArchivoManager.leerDoctores();
        List<Paciente> pacientes = ArchivoManager.leerPacientes();

        if (doctores.isEmpty() || pacientes.isEmpty()) {
            System.out.println("Debe haber al menos un doctor y un paciente registrados.");
            return;
        }

        System.out.println("Lista de Doctores:");
        for (int i = 0; i < doctores.size(); i++) {
            Doctor d = doctores.get(i);
            System.out.println((i + 1) + ". " + d.getNombre() + " (" + d.getEspecialidad() + ")");
        }

        System.out.print("Seleccione un doctor (número): ");
        int indexDoctor = scanner.nextInt() - 1;
        scanner.nextLine();
        if (indexDoctor < 0 || indexDoctor >= doctores.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        System.out.println("Lista de Pacientes:");
        for (int i = 0; i < pacientes.size(); i++) {
            Paciente p = pacientes.get(i);
            System.out.println((i + 1) + ". " + p.getNombre());
        }

        System.out.print("Seleccione un paciente (número): ");
        int indexPaciente = scanner.nextInt() - 1;
        scanner.nextLine();
        if (indexPaciente < 0 || indexPaciente >= pacientes.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        System.out.print("ID de la cita: ");
        String id = scanner.nextLine();
        System.out.print("Fecha y hora (formato: dd/mm/aaaa hh:mm): ");
        String fechaHora = scanner.nextLine();
        System.out.print("Motivo de la cita: ");
        String motivo = scanner.nextLine();

        Doctor doctor = doctores.get(indexDoctor);
        Paciente paciente = pacientes.get(indexPaciente);
        Cita cita = new Cita(id, fechaHora, motivo, doctor, paciente);

        ArchivoManager.guardarCita(cita);
        System.out.println("Cita creada y guardada exitosamente.");
    }
}
