package com.mycompany.consultoriocitas;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoManager {

    private static final String CARPETA_DB = "db";
    private static final String DOCTORES_PATH = CARPETA_DB + "/doctores.csv";
    private static final String PACIENTES_PATH = CARPETA_DB + "/pacientes.csv";
    private static final String CITAS_PATH = CARPETA_DB + "/citas.csv";

    private static void asegurarDirectorio() {
        File carpeta = new File(CARPETA_DB);
        if (!carpeta.exists()) {
            boolean creada = carpeta.mkdirs();
            if (creada) {
                System.out.println("Carpeta 'db' creada automáticamente.");
            } else {
                System.out.println("No se pudo crear la carpeta 'db'. Verifica permisos.");
            }
        }
    }

    public static void guardarDoctor(Doctor doctor) {
        asegurarDirectorio();
        try (PrintWriter pw = new PrintWriter(new FileWriter(DOCTORES_PATH, true))) {
            pw.println(doctor.toString());
        } catch (IOException e) {
            System.out.println("Error al guardar el doctor: " + DOCTORES_PATH + " (" + e.getMessage() + ")");
        }
    }

    public static List<Doctor> leerDoctores() {
        List<Doctor> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(DOCTORES_PATH))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    lista.add(new Doctor(partes[0], partes[1], partes[2]));
                }
            }
        } catch (IOException e) {
            System.out.println("Archivo de doctores no encontrado, se creará al guardar uno nuevo.");
        }
        return lista;
    }

    public static void guardarPaciente(Paciente paciente) {
        asegurarDirectorio();
        try (PrintWriter pw = new PrintWriter(new FileWriter(PACIENTES_PATH, true))) {
            pw.println(paciente.toString());
        } catch (IOException e) {
            System.out.println("Error al guardar el paciente: " + PACIENTES_PATH + " (" + e.getMessage() + ")");
        }
    }

    public static List<Paciente> leerPacientes() {
        List<Paciente> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(PACIENTES_PATH))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    lista.add(new Paciente(partes[0], partes[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Archivo de pacientes no encontrado, se creará al guardar uno nuevo.");
        }
        return lista;
    }

    public static void guardarCita(Cita cita) {
        asegurarDirectorio();
        try (PrintWriter pw = new PrintWriter(new FileWriter(CITAS_PATH, true))) {
            pw.println(cita.toString());
        } catch (IOException e) {
            System.out.println("Error al guardar la cita: " + CITAS_PATH + " (" + e.getMessage() + ")");
        }
    }
}
